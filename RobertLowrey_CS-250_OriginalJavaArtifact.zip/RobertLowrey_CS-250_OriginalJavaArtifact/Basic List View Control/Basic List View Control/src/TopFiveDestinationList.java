import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
                topDestinationListFrame.setTitle("Top 5 Destination List");
                topDestinationListFrame.setVisible(true);
            }
        });
    }
}


class TopDestinationListFrame extends JFrame {
    private DefaultListModel listModel;

    public TopDestinationListFrame() {
        super("Top Five Destination List");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);

        listModel = new DefaultListModel();


        //Make updates to your top 5 list below. Import the new image files to resources directory.
        addDestinationNameAndPicture("1. Rome - A goegeous historic city that still holds glory!", new ImageIcon(getClass().getResource("/resources/Colosseum_in_Rome.jpg"))); //This will import the first image and display the description sentence
        addDestinationNameAndPicture("2. Greece - Beautiful blue beaches, and amazing culture! ", new ImageIcon(getClass().getResource("/resources/Santorini_-_Greece.jpg")));//This will import the second listing image and display the description sentence
        addDestinationNameAndPicture("3. Paris, France - The most romantic city, great for anniversaries!", new ImageIcon(getClass().getResource("/resources/Seine_in_Paris.jpg")));//This will import the third image and display the description sentence
        addDestinationNameAndPicture("4. Sydney, Austrailia - Amazing architecture and great shows!", new ImageIcon(getClass().getResource("/resources/Sydney_Opera_House_and_Harbour_Bridge.jpg")));//This will import the fourth listing image and display the description sentence
        addDestinationNameAndPicture("5. Taj Mahal, India - The greatest example of Mughal architecture!", new ImageIcon(getClass().getResource("/resources/Taj_Mahal.jpg")));//This will import the 5th and last image and display the description sentence
        
        
        JList list = new JList(listModel);
        JScrollPane scrollPane = new JScrollPane(list);

        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(2);

        list.setBackground(Color.DARK_GRAY); //this will change the overall background to dark gray
        list.setSelectionBackground(Color.PINK); // this will change the color of the listing pink when it is selected.
        list.setCellRenderer(renderer);
        
        
        JLabel nameLabel = new JLabel ("Developer: Robert Lowrey"); //this will add my name to the JFrame
        getContentPane().add(nameLabel, BorderLayout.NORTH); // this will put my name at the top of the list
        getContentPane().add(scrollPane, BorderLayout.EAST); //This will align the list to the left to make it more organized
    }

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
    }
}


class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
}


class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);

    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(0, 0, 0, 0);
    }

    public TextAndIconListCellRenderer(int padding) {
        this(padding, padding, padding, padding);
    }

    public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
        insideBorder = BorderFactory.createEmptyBorder(topPadding, leftPadding, bottomPadding, rightPadding);
        setOpaque(true);
    }

    public Component getListCellRendererComponent(JList list, Object value,
    int index, boolean isSelected, boolean hasFocus) {
        // The object from the combo box model MUST be a TextAndIcon.
        TextAndIcon tai = (TextAndIcon) value;

        // Sets text and icon on 'this' JLabel.
        setText(tai.getText());
        setIcon(tai.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder;

        if (hasFocus) {
            outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }

    // The following methods are overridden to be empty for performance
    // reasons. If you want to understand better why, please read:
    //
    // http://java.sun.com/javase/6/docs/api/javax/swing/DefaultListCellRenderer.html#override

    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}